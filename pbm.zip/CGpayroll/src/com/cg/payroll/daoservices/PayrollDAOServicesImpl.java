package com.cg.payroll.daoservices;
import com.cg.payroll.beans.*;
public class PayrollDAOServicesImpl {
	
				private static Associate[] associateList = new Associate[10];
				private static int ASSOCIATE_ID_COUNTER=111;
				private static int ASSOCIATE_IDX_COUNTER=0;
							
	int insertAssociate(Associate associate){
		associate.setAssociateId(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateId();
	}
	boolean updateAssociate(Associate associate){
		for(int i=0;i<associateList.length;i++){
			if(associate.getAssociateId()==associateList[i].getAssociateId())
				associateList[i]=associate;
			return true;		
		}	
		return false;
	}
	boolean deleteAssociate(int associateId){
		for(int i=0;i<associateList.length;i++){
			if(associateId ==associateList[i].getAssociateId())
				associateList[i]=null;
			associateList[i] = new Associate();
			associateList[i].setAssociateId(associateId);
			
			return true;		
		}	
		return false;
	}
	Associate getAssociate(int associateId){
		for(int i=0;i<associateList.length;i++){
			if(associateId ==associateList[i].getAssociateId())
		return associateList[i];
		}
		return null;
	}
	Associate[] getAssociates(){
		return associateList;
	}
}
