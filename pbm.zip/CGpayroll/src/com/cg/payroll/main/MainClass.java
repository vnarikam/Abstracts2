package com.cg.payroll.main;
import com.cg.payroll.beans.*;

public class MainClass {

	public static void main(String[] args) {
		Associate1 obj [ ] []= new Associate1[3][5];
		obj[0][0]=new Associate1(111, 125, "pavan"," kalyan", "ece"," se"," gsdgh", "ghdsf");
		obj[0][1]=new Associate1(121, 125, "npavan"," kalyan", "eee"," se"," gsdgh", "ghdsf");
		BankDetails bankDetails = new BankDetails(21212, "212", "2121");
		Salary salary =new Salary(1000, 1000, 100, 11, 11, 11, 11, 11, 11, 11, 11);
	System.out.println(obj[0][1].getAssociateId()+"  "+obj[1][0].getDepartment());
	}
	
	


}
