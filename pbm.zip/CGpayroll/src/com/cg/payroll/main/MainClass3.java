package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.*;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.*;
public class MainClass3{
	PayrollServicesImpl payrollServices = new PayrollServicesImpl();

	public static void main(String[] args) {
		Associate associate =searchAssociate("pava");
		if(associate!=null)
		System.out.println(associate.getAssociateId());
		else
		System.out.println("not found");	
	}
public static Associate searchAssociate(String Name){
	Associate associates[] =new Associate[3];
	associates[0]=new Associate(199,123666,"pavan","kalyan","ece","analyst","BCKPT3639R","siva@gamil.com",new Salary(102525, 5200, 5000, 250, 5600, 230, 1000, 1000, 2500, 56233, 2555),new BankDetails(11111,"HDFC","HDFC50123"));
	associates[1]=new Associate(222,1238951,"surya","ece","depa","analyst","BPKTGG3444","surya@gamil.com",new Salary(22555,565,258,258,548,250,1000,1000,5000,52300,60236),new BankDetails(258963,"HDFC","HDFC5032"));
	for(Associate associate:associates){
		if( associate!=null&&associate.getFirstName()==Name&&associate.getYearlyInvestmentUnder80C()>15000&&associate.getSalary().getBasicSalary()>=35000 )
			return associate;
	}
	return null;
}
}

