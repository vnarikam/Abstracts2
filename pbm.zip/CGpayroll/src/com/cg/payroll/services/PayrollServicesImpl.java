package com.cg.payroll.services;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.*;
public class PayrollServicesImpl {
	
	private PayrollDAOServicesImpl daoServices;
	
	public PayrollServicesImpl(){
		daoServices = new PayrollDAOServicesImpl();
	}
	
	public int acceptAssociateDetails(String firstName, String lastName,String department, String designation,
			String pancard, String emailId, int yearlyInvestmentUnder80C,float basicSalary,float epf, 
			float companyPf,int accountNumber, String bankName, String ifscCode){
		return 0;

	}
	public int calculateNetSalary(int associate){
		return 0;
	}
	public Associate getAssociateDetails(int associateId){
		return null;
	}
	public Associate[] getAllAssociateDetails(){
		return null;
	}
}


