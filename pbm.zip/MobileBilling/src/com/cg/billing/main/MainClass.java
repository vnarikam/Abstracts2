package com.cg.billing.main;
import com.cg.billing.beans.*;
import com.cg.billing.beans.Address; 
public class MainClass {

	public static void main(String[] args) {
			Customer [] customers = new Customer[2];
			PostpaidAccount [] accounts = new PostpaidAccount[2];
			PostpaidAccount [] accounts1 = new PostpaidAccount[2];
			Bill [] bills = new Bill[2];
			Bill [] bills1 = new Bill[2];
			customers[0] = new Customer(12345,852963,741258,"pavan","kalyan","sivapavan@gmail.com","22js22585","21/10/1995",accounts,new Address(521105,"junction","A.P","India"));
			customers[1] = new Customer(258,741258,963258,"mani","kanta","mani@gmail.com","25fff258","21/52/5878",accounts,new Address(534201, "Bhimavara", "A.P", "India"));
			accounts[0] = new PostpaidAccount(8985816274l,new Plan(123l,10l,"25min","10min","10","10","MB","10p per sec","20p per sec","1rs per sms","2rs per sms","10p per KB","A.P","P.K"),bills);
			accounts1[0] = new PostpaidAccount(8985816275l,new Plan(123l,10l,"25min","10min","10","10","MB","10p per sec","20p per sec","1rs per sms","2rs per sms","10p per KB","A.P","P.K"),bills1);
			bills[0] = new Bill("April",1234,10,15,25,10,120,123,10,10,20,20,25,120);
			bills1[0] = new Bill("Month",1234,10,15,25,10,120,123,10,10,20,20,25,120);
	}

}
