package com.cg.billing.beans;

public class PostpaidAccount {
	private long mobileNo;
	private Plan plan;
	private Bill [] bills;
	public PostpaidAccount(){}
	public PostpaidAccount(long mobileNo, Plan plan, Bill[] bills) {
		super();
		this.mobileNo = mobileNo;
		this.plan = plan;
		this.bills = bills;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Plan getPlan() {
		return plan;
	}
	public void setPlan(Plan plan) {
		this.plan = plan;
	}
	public Bill[] getBills() {
		return bills;
	}
	public void setBills(Bill[] bills) {
		this.bills = bills;
	}
	
}
