package com.cg.billing.beans;

public class Plan {
	private long planId,monthlyRental;
	private String freeLocalCalls, freeStdCalls, freeLocalSMS, freeStdSMS, freeInternetDataUsageUnits,
	localCallRate, stdCallRate, localSMSRate, stdSMSRate, internetDataUsageRate,
	planCircle, planName;
	public Plan(){}
	public Plan(long planId, long monthlyRental, String freeLocalCalls, String freeStdCalls, String freeLocalSMS,
			String freeStdSMS, String freeInternetDataUsageUnits, String localCallRate, String stdCallRate,
			String localSMSRate, String stdSMSRate, String internetDataUsageRate, String planCircle, String planName) {
		super();
		this.planId = planId;
		this.monthlyRental = monthlyRental;
		this.freeLocalCalls = freeLocalCalls;
		this.freeStdCalls = freeStdCalls;
		this.freeLocalSMS = freeLocalSMS;
		this.freeStdSMS = freeStdSMS;
		this.freeInternetDataUsageUnits = freeInternetDataUsageUnits;
		this.localCallRate = localCallRate;
		this.stdCallRate = stdCallRate;
		this.localSMSRate = localSMSRate;
		this.stdSMSRate = stdSMSRate;
		this.internetDataUsageRate = internetDataUsageRate;
		this.planCircle = planCircle;
		this.planName = planName;
	}
	public long getPlanId() {
		return planId;
	}
	public void setPlanId(long planId) {
		this.planId = planId;
	}
	public long getMonthlyRental() {
		return monthlyRental;
	}
	public void setMonthlyRental(long monthlyRental) {
		this.monthlyRental = monthlyRental;
	}
	public String getFreeLocalCalls() {
		return freeLocalCalls;
	}
	public void setFreeLocalCalls(String freeLocalCalls) {
		this.freeLocalCalls = freeLocalCalls;
	}
	public String getFreeStdCalls() {
		return freeStdCalls;
	}
	public void setFreeStdCalls(String freeStdCalls) {
		this.freeStdCalls = freeStdCalls;
	}
	public String getFreeLocalSMS() {
		return freeLocalSMS;
	}
	public void setFreeLocalSMS(String freeLocalSMS) {
		this.freeLocalSMS = freeLocalSMS;
	}
	public String getFreeStdSMS() {
		return freeStdSMS;
	}
	public void setFreeStdSMS(String freeStdSMS) {
		this.freeStdSMS = freeStdSMS;
	}
	public String getFreeInternetDataUsageUnits() {
		return freeInternetDataUsageUnits;
	}
	public void setFreeInternetDataUsageUnits(String freeInternetDataUsageUnits) {
		this.freeInternetDataUsageUnits = freeInternetDataUsageUnits;
	}
	public String getLocalCallRate() {
		return localCallRate;
	}
	public void setLocalCallRate(String localCallRate) {
		this.localCallRate = localCallRate;
	}
	public String getStdCallRate() {
		return stdCallRate;
	}
	public void setStdCallRate(String stdCallRate) {
		this.stdCallRate = stdCallRate;
	}
	public String getLocalSMSRate() {
		return localSMSRate;
	}
	public void setLocalSMSRate(String localSMSRate) {
		this.localSMSRate = localSMSRate;
	}
	public String getStdSMSRate() {
		return stdSMSRate;
	}
	public void setStdSMSRate(String stdSMSRate) {
		this.stdSMSRate = stdSMSRate;
	}
	public String getInternetDataUsageRate() {
		return internetDataUsageRate;
	}
	public void setInternetDataUsageRate(String internetDataUsageRate) {
		this.internetDataUsageRate = internetDataUsageRate;
	}
	public String getPlanCircle() {
		return planCircle;
	}
	public void setPlanCircle(String planCircle) {
		this.planCircle = planCircle;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	
}
