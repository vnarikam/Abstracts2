package com.cg.employee.main;
import com.cg.employee.beans.*;
public class MainClass {

	public static void main(String[] args) {
		Emplyee emplyee = new Emplyee(12345,5000f,"pavan","kalyan");
		emplyee.calculateSalary();
		System.out.println(emplyee.toString());
		PEmployee pemployee = new PEmployee(123456,5000f,"anil","kumar");
		pemployee.calculateSalary();
		System.out.println(pemployee.toString());
		CEmployee cemployee = new CEmployee(123456,"pava","kalyan",20f,100f);
		cemployee.calculateSalary();
		System.out.println(cemployee.toString());
	}
}
