package com.cg.employee.beans;

public class PEmployee extends Emplyee{
	private float hra,ta,da;

	public PEmployee() {
		super();
	}

	public PEmployee(int employeeId, float basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	}


	public PEmployee(int employeeId, float basicSalary, String firstName, String lastName,float hra, float ta, float da,float totalSalary) {
		super(employeeId, basicSalary, firstName, lastName);
		this.hra = hra;
		this.ta = ta;
		this.da = da;
	}


	public float getHra() {
		return hra;
	}


	public void setHra(float hra) {
		this.hra = hra;
	}


	public float getTa() {
		return ta;
	}


	public void setTa(float ta) {
		this.ta = ta;
	}


	public float getDa() {
		return da;
	}


	public void setDa(float da) {
		this.da = da;
	}
	public void calculateSalary() {
		this.hra = this.getBasicSalary()*0.1f;
		this.da=this.getBasicSalary()*0.08f;
		this.ta=this.getBasicSalary()*0.05f;
		this.setTotalSalary(this.da+this.hra+this.ta+this.getBasicSalary());
		
	}

	@Override
	public String toString() {
		return "PEmployee [hra=" + hra + ", ta=" + ta + ", da=" + da + "]";
	}
	
}