package com.cg.employee.beans;

public class Developer extends PEmployee {

	public Developer() {
		super();
	}
	public CEmployee(int employeeId, float basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	}

}
